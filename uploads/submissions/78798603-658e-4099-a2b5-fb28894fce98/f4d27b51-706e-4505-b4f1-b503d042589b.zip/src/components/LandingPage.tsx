import { motion } from 'motion/react';
import { ArrowRight, Shield, Users, TrendingUp, Bell, FileText, Smartphone } from 'lucide-react';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <motion.header 
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className="container mx-auto px-4 py-6"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
            <span className="text-gray-900">PayTrack Pro</span>
          </div>
          <Button onClick={onGetStarted} variant="outline">
            Sign In
          </Button>
        </div>
      </motion.header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="inline-block mb-4 px-4 py-2 rounded-full bg-indigo-100 text-indigo-700">
              <span>✨ Admin Payment Management System</span>
            </div>
            <h1 className="text-gray-900 mb-6">
              Manage Member Payments with Ease
            </h1>
            <p className="text-gray-600 mb-8">
              A powerful admin dashboard to track payments, manage members, send automated reminders, 
              and export detailed reports. Everything you need to streamline your payment collection process.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                onClick={onGetStarted}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700"
              >
                Get Started <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button variant="outline">
                Learn More
              </Button>
            </div>
            <div className="flex items-center gap-8 mt-12">
              <div>
                <div className="text-gray-900">500+</div>
                <div className="text-gray-600">Active Admins</div>
              </div>
              <div className="w-px h-12 bg-gray-300" />
              <div>
                <div className="text-gray-900">50K+</div>
                <div className="text-gray-600">Members Managed</div>
              </div>
              <div className="w-px h-12 bg-gray-300" />
              <div>
                <div className="text-gray-900">99.9%</div>
                <div className="text-gray-600">Uptime</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="relative"
          >
            <div className="relative rounded-2xl overflow-hidden shadow-2xl">
              <ImageWithFallback 
                src="https://images.unsplash.com/photo-1615775036480-f0cff4e2ff6d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXltZW50JTIwZGFzaGJvYXJkJTIwZmluYW5jZXxlbnwxfHx8fDE3NjQ5MTY1NDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Dashboard Preview"
                className="w-full h-auto"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-indigo-900/50 to-transparent" />
            </div>
            {/* Floating Card */}
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.8, delay: 1, repeat: Infinity, repeatType: 'reverse', repeatDelay: 2 }}
              className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-6 max-w-xs"
            >
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <div className="text-gray-600">Payment Received</div>
                  <div className="text-gray-900">₹5,500</div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-gray-900 mb-4">
            Everything You Need to Manage Payments
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Powerful features designed specifically for admins to efficiently track, manage, 
            and collect payments from members.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-6`}>
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-gray-900 mb-3">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-12 text-center"
        >
          <h2 className="text-white mb-4">
            Ready to Streamline Your Payment Management?
          </h2>
          <p className="text-indigo-100 mb-8 max-w-2xl mx-auto">
            Join hundreds of admins who trust PayTrack Pro to manage their member payments efficiently.
          </p>
          <Button 
            onClick={onGetStarted}
            className="bg-white text-indigo-600 hover:bg-gray-100"
          >
            Start Free Trial <ArrowRight className="ml-2 w-4 h-4" />
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="container mx-auto px-4 py-12 border-t border-gray-200">
        <div className="text-center text-gray-600">
          <p>&copy; 2025 PayTrack Pro. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

const features = [
  {
    icon: Users,
    title: 'Member Management',
    description: 'Add, edit, and manage unlimited members with detailed profiles and payment history.',
    gradient: 'from-blue-500 to-cyan-500'
  },
  {
    icon: Bell,
    title: 'Smart Reminders',
    description: 'Automated WhatsApp notifications for due dates and payment reminders.',
    gradient: 'from-purple-500 to-pink-500'
  },
  {
    icon: FileText,
    title: 'Export Reports',
    description: 'Export payment details to Excel with custom date ranges and filters.',
    gradient: 'from-orange-500 to-red-500'
  },
  {
    icon: Shield,
    title: 'Secure & Reliable',
    description: 'Your data is encrypted and backed up automatically for peace of mind.',
    gradient: 'from-green-500 to-emerald-500'
  },
  {
    icon: TrendingUp,
    title: 'Payment Tracking',
    description: 'Real-time tracking of paid and unpaid members with detailed analytics.',
    gradient: 'from-indigo-500 to-blue-500'
  },
  {
    icon: Smartphone,
    title: 'Mobile Friendly',
    description: 'Access your dashboard from any device, anywhere, anytime.',
    gradient: 'from-pink-500 to-rose-500'
  }
];
