import { useState, useEffect } from 'react';
import { LandingPage } from './components/LandingPage';
import { AuthPage } from './components/AuthPage';
import { SubscriptionPage } from './components/SubscriptionPage';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from './components/ui/sonner';

export type UserData = {
  name: string;
  email: string;
  phone: string;
  businessName: string;
  logo?: string;
  businessDetails?: string;
  accountNumber?: string;
};

export type AppPage = 'landing' | 'auth' | 'subscription' | 'dashboard';

function App() {
  const [currentPage, setCurrentPage] = useState<AppPage>('landing');
  const [userData, setUserData] = useState<UserData | null>(null);
  const [hasSubscription, setHasSubscription] = useState(false);

  useEffect(() => {
    // Check if user is logged in
    const storedUser = localStorage.getItem('userData');
    const storedSubscription = localStorage.getItem('hasSubscription');
    
    if (storedUser && storedSubscription === 'true') {
      setUserData(JSON.parse(storedUser));
      setHasSubscription(true);
      setCurrentPage('dashboard');
    } else if (storedUser) {
      setUserData(JSON.parse(storedUser));
      setCurrentPage('subscription');
    }
  }, []);

  const handleAuthSuccess = (user: UserData) => {
    setUserData(user);
    localStorage.setItem('userData', JSON.stringify(user));
    setCurrentPage('subscription');
  };

  const handleSubscriptionSuccess = () => {
    setHasSubscription(true);
    localStorage.setItem('hasSubscription', 'true');
    setCurrentPage('dashboard');
  };

  const handleLogout = () => {
    setUserData(null);
    setHasSubscription(false);
    localStorage.removeItem('userData');
    localStorage.removeItem('hasSubscription');
    setCurrentPage('landing');
  };

  return (
    <div className="min-h-screen">
      <Toaster position="top-right" richColors />
      {currentPage === 'landing' && (
        <LandingPage onGetStarted={() => setCurrentPage('auth')} />
      )}
      {currentPage === 'auth' && (
        <AuthPage onAuthSuccess={handleAuthSuccess} />
      )}
      {currentPage === 'subscription' && userData && (
        <SubscriptionPage 
          onSubscriptionSuccess={handleSubscriptionSuccess}
          onBack={() => setCurrentPage('auth')}
        />
      )}
      {currentPage === 'dashboard' && userData && (
        <AdminDashboard 
          userData={userData}
          onUserDataUpdate={setUserData}
          onLogout={handleLogout}
        />
      )}
    </div>
  );
}

export default App;